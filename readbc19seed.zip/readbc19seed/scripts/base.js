$(document).ready(function () {
  $( '.footer_fascade' ).mouseenter(
    function() {
      $('.footer').css('transform','translateY(5px)');
    }
  ).mouseleave(function(){
    $('.footer').css('transform','translateY(60px)');
  });
  $('.footer').mouseenter(function() {
    $('.footer').css('transform','translateY(5px)');
  })
  $('.footer').mouseleave(function() {
      $('.footer').css('transform','translateY(60px)');
    });
});